import artimimpi from './artimimpi.js'
import artinama from './artinama.js'
import nomorhoki from './nomorhoki.js'
import getZodiac from './zodiac.js'

export { artinama, artimimpi, nomorhoki, getZodiac }
