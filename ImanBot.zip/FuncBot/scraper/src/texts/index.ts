import bucin, { bucinjson } from './bucin.js'
import dare, { darejson } from './dare.js'
import truth, { truthjson } from './truth.js'
import textpro, { textproList } from './textpro.js'

export * from './aksarajawa.js'
export {
  bucin, bucinjson,
  dare, darejson,
  truth, truthjson,
  textpro, textproList
}
